-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 16-05-2019 a las 13:17:50
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `foro`
--
CREATE DATABASE `foro` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `foro`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--
-- Creación: 26-02-2019 a las 12:45:23
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `cat_id` int(8) NOT NULL AUTO_INCREMENT,
  `cat_nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `cat_descripcion` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `nombre` (`cat_nombre`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`cat_id`, `cat_nombre`, `cat_descripcion`) VALUES
(9, 'CategorÃ­a prueba 1', 'Ejemplo de categorÃ­a');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `posts`
--
-- Creación: 26-02-2019 a las 13:06:30
--

CREATE TABLE IF NOT EXISTS `posts` (
  `posts_id` int(8) NOT NULL AUTO_INCREMENT,
  `posts_contenido` text COLLATE utf8_spanish_ci NOT NULL,
  `posts_fecha` datetime NOT NULL,
  `posts_tema` int(8) NOT NULL,
  `posts_autor` int(8) NOT NULL,
  PRIMARY KEY (`posts_id`),
  KEY `posts_autor` (`posts_autor`),
  KEY `posts_tema` (`posts_tema`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=56 ;

--
-- Volcado de datos para la tabla `posts`
--

INSERT INTO `posts` (`posts_id`, `posts_contenido`, `posts_fecha`, `posts_tema`, `posts_autor`) VALUES
(54, 'Ejemplo de un tema dentro de una categoria', '2019-05-16 15:02:59', 19, 14),
(55, 'Ejemplo de respuesta dentro de un tema', '2019-05-16 15:03:31', 19, 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temas`
--
-- Creación: 26-02-2019 a las 13:02:33
--

CREATE TABLE IF NOT EXISTS `temas` (
  `tema_id` int(8) NOT NULL AUTO_INCREMENT,
  `tema_nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `tema_fecha` datetime NOT NULL,
  `tema_categoria` int(8) NOT NULL,
  `tema_autor` int(8) NOT NULL,
  PRIMARY KEY (`tema_id`),
  KEY `tema_categoria` (`tema_categoria`),
  KEY `tema_autor` (`tema_autor`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=20 ;

--
-- Volcado de datos para la tabla `temas`
--

INSERT INTO `temas` (`tema_id`, `tema_nombre`, `tema_fecha`, `tema_categoria`, `tema_autor`) VALUES
(19, 'Ejemplo de tema', '2019-05-16 15:02:59', 9, 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--
-- Creación: 26-02-2019 a las 12:40:33
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_nombre` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `usuario_password` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `usuario_email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `usuario_fecha` datetime NOT NULL,
  `usuario_nivel` int(8) NOT NULL,
  PRIMARY KEY (`usuario_id`),
  UNIQUE KEY `id` (`usuario_id`,`usuario_nombre`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usuario_id`, `usuario_nombre`, `usuario_password`, `usuario_email`, `usuario_fecha`, `usuario_nivel`) VALUES
(14, 'root', '81dc9bdb52d04dc20036dbd8313ed055', '', '2019-05-16 11:53:38', 0);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_3` FOREIGN KEY (`posts_autor`) REFERENCES `usuarios` (`usuario_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `temas`
--
ALTER TABLE `temas`
  ADD CONSTRAINT `temas_ibfk_2` FOREIGN KEY (`tema_categoria`) REFERENCES `categorias` (`cat_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `temas_ibfk_4` FOREIGN KEY (`tema_autor`) REFERENCES `usuarios` (`usuario_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
